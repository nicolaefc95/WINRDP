<?php

/* data mining */

$sign = "xxx";
$auth = "xxx";

/* data email */

$sign1 = "xxxxx";
$auth1 = "xxxx";


/* cookie */

$user_agent = "xxx";
$ct_ts = "xxx";
$token = "xxx";
$session = "xxx";
$bid = "xxx";
$ct_v = "xxx";
$ct_av = "xxx";



?>
